using System;
using UnityEngine;


namespace UnityStandardAssets.Utility
{
    public class FollowTarget : MonoBehaviour
    {
        public Transform target;
        public Vector3 offset = new Vector3(0f, 7.5f, 0f);
        public float minX;
        public float minY;
        public float maxX;
        public float maxY;

        void Start()
        {
            transform.position = target.position + offset;
            if (target.position.y > maxY)
            {
                transform.position = new Vector3(0, transform.position.y - (target.position.y - maxY), 0);
            }
            if (target.position.x > maxX)
            {
                transform.position = new Vector3(0, transform.position.x - (target.position.x - maxY), 0);
            }
            if (target.position.x < minX)
            {
                transform.position = new Vector3(0, transform.position.x + (target.position.x - minX), 0);
            }
            if (target.position.y < minY)
            {
                transform.position = new Vector3(0, transform.position.y + (target.position.y - minY), 0);
            }
        }
        private void LateUpdate()
        {
            Vector3 newPos = target.position;
            if (newPos.x > minX && newPos.x < maxX && newPos.y > minY && newPos.y < maxY)
            {
                transform.position = newPos + offset;
            } else if (newPos.x > minX && newPos.x < maxX) {
                transform.position = new Vector3(newPos.x + offset.x, transform.position.y, offset.z);
            }
            else if (newPos.y > minY && newPos.y < maxY)
            {
                transform.position = new Vector3(transform.position.x, newPos.y + offset.y, offset.z);
            }
        }
    }
}
