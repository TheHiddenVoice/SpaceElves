﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyStats : MonoBehaviour {

    // Use this for initialization
    public string Name = "Sprikaan";
    public string Title = "Cthulu Jr.";
    public string description = "They suck, they attack, but more importantly, you can't come back.";
    public int VIT = 25; //Health
    public int MP = 15; //Mana
    public int STR = 4; //Attack
    public int DEX = 8; //Dexterity
    public int INT = 12; //Intelligence
    public int RES = 2; //Damage Resistance
    public int SPD = 9; //Speed
    public int LUK = 3; //Luck
    public int LV = 2; //Level

}
