﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PartyStats : MonoBehaviour {
    public string Name = "Craig";
    public string Title = "Epic Bartender";
    public string description = "The most fabulous bartender";
    public int VIT = 50; //Health
    public int MP = 25; //Mana
    public int STR = 10; //Attack
    public int DEX = 10; //Dexterity
    public int CHA = 10; //Charisma
    public int INT = 10; //Intelligence
    public int RES = 10; //Damage Resistance
    public int SPD = 10; //Speed
    public int LUK = 10; //Luck
    public int LV = 1; //Level
    public int EXP = 0; //Exp

    //Max stats
    public int MVT = 200;
    public int MMP = 100;
    public int MSR = 50;
    public int MDX = 50;
    public int MCH = 50;
    public int MIN = 50;
    public int MRS = 50;
    public int MSD = 50;
    public int MLK = 50;
    public int MLV = 50;
    public int MXP = 100;

    //Modifiers
    public int STMod = 2;
    public int MPMod = 5;
    public int VTMod = 10;
    public int DXMod = 3;
    public int CHMod = 5;
    public int INMod = 4;
    public int RSMod = 2;
    public int SDMod = 4;
    public int LKMod = 9;
	
	// Update is called once per frame
	void Update () {

        //Checks to make sure there are no stats above the max
        if (LV > MLV)
            LV = MLV;

        if (VIT > MVT)
            VIT = MVT;

        if (MP > MMP)
            MP = MMP;

        if (STR > MSR)
            STR = MSR;

        if (DEX > MDX)
            DEX = MDX;

        if (CHA > MCH)
            CHA = MCH;

        if (INT > MIN)
            INT = MIN;

        if (RES > MRS)
            RES = MMP;

        if (SPD > MSD)
            SPD = MSD;

        if (LUK > MLK)
            LUK = MLK;

        if (EXP >= MXP)
            LevelUp();
    }
    
    //This fuction triggers a level up

    void LevelUp()
    {
        LV = LV + 1;
        EXP = EXP - MXP;
        VIT = VIT + VTMod;
        MP = MP + MPMod;
        STR = STR + STMod;
        DEX = DEX + DXMod;
        INT = INT + INMod;
        CHA = CHA + CHMod;
        RES = RES + RSMod;
        SPD = SPD + SDMod;
        LUK = LUK + LKMod;
    }

    public void AwardExp(int exp)
    {
        EXP = EXP + exp;
    }
    
}
