﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PartyManager : MonoBehaviour {

    //0 = None Selected
    //1 = Iniko Albright
    //2 = Nathaniel Eisenburg
    //3 = Patrice Halwick
    //4 = Sarkis Cherrymeade
    //5 = Abden Eldr
    public int[] members = { 1, 2, 3, 0, 0 };
    public int Gold = 300;
    public string GoldText = "Gald";

    /*
     * 1 = 
     * 2 =
     * 3 =
     * 4 =
     * 5 =
     * 6 =
     * 7 =
     * 8 =
     * 9 =
     */
    public int[] ItemInventory;

    // Update is called once per frame
    public void addMember(int member)
    {
        if(member <= 5 && member >= 0)
        {
            for (int i = 0; i > members.Length; i++)
            {
                if (members[i] == 0)
                {
                    members[i] = member;
                }
            }
        } else
        {
            print("Not a valid party member");
        }
    }
    public int getCash()
    {
        return Gold;
    }

    public void setCash(int money)
    {
        if(money <= Gold)
        {
            Gold = Gold - money;
        } else
        {
            print("Not enough money");
        }
    }
    
}
