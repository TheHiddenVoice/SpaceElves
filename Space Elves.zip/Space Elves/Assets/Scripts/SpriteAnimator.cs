﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpriteAnimator : MonoBehaviour {

    public Animator anim;
	// Use this for initialization
	void Start () {
        anim = GetComponent<Animator>();
	}
	
	// Update is called once per frame
	void Update () {
        //If the character goes up (down)
        if (Input.GetKey(KeyCode.W) || Input.GetKey(KeyCode.UpArrow))
        {
            anim.SetFloat("Pos X", 0);
            anim.SetFloat("Pos Y", -1);
            anim.SetBool("Walking", true);
        }

        //If the character goes up
        if (Input.GetKey(KeyCode.A) || Input.GetKey(KeyCode.LeftArrow))
        {
            anim.SetFloat("Pos X", -1);
            anim.SetFloat("Pos Y", 0);
            anim.SetBool("Walking", true);
        }

        //If the character goes down (up)
        if (Input.GetKey(KeyCode.S) || Input.GetKey(KeyCode.DownArrow))
        {
            anim.SetFloat("Pos X", 0);
            anim.SetFloat("Pos Y", 1);
            anim.SetBool("Walking", true);
        }

        //If the character goes right
        if (Input.GetKey(KeyCode.D) || Input.GetKey(KeyCode.RightArrow))
        {
            anim.SetFloat("Pos X", 1);
            anim.SetFloat("Pos Y", 0);
            anim.SetBool("Walking", true);
        }
        if(Input.anyKey == false)
        {
            anim.SetBool("Walking", false);
        }
    }
}
