﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WeaponStats : MonoBehaviour {

    public bool unique = false; //Unique Weapons
    public int ATK = 10; //Damage modifier
    public bool spmod = false; //If the weapon affects something else
    public string SpecialMod = "SPD"; //The type of stat it affects
    public int Special = 5; //The special modifier
    public string Skill = "Water Strike"; //Special crit skill
    public bool ranged = false; //If the weapon is ranged
    public PartyStats stats; //The link to the character stats
    public EnemyStats enemyStats; //The link to the enemy stats

    // 0 = nothing
    // 1 = laser
    // 2 = radiation
    // 3 = plasma
    // 4 = kinetic
    // 5 = elemental
    public int Type = 1;
    //Fire
    //Water
    //Ice
    //Lightning
    //Air
    //Earth
    //Nothing
    public string Element = "";

    //Swords
    //Spears
    //Axes
    //Guns
    //Fire
    //Bow/Crossbow
    //Knives
    //Staves
    public string type = "Sword";

    //This fuction deals damage
    public int DealDamage()
    {
        int damage = 0;
        if (ranged == false)
        {
            damage = (stats.STR + ATK) * 2 - (enemyStats.RES);
        } else {
            damage = (stats.DEX + ATK) * 2 - (enemyStats.RES);
        }
        //if the damage is negative
        if (damage < 0)
        {
            damage = 0;
        }
        return damage;
    }//End DealDamage


}
