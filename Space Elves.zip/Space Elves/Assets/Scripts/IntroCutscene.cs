﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class IntroCutscene : MonoBehaviour {

    public MessageWindow window;

    void Start()
    {
        StartCoroutine(Cutscene());
    }
	
	IEnumerator Cutscene()
    {
        // Just a habit of mine, specifically for new folk. You look confused, which is a dead giveaway that you’ve never been around these parts. 
        window.InputText("Welcome, patron. I trust you’re comfortable? The name’s Craig Drew and I make sure all newcomers are nice and snug before I start info dumping them.");
        yield return 120;
    }
}
