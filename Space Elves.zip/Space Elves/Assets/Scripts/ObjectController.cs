﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObjectController : MonoBehaviour {

    public bool HasItem = false;
    public bool HasMessage = true;
    public bool HasEvent = false;

    public string Message = "";

    public MessageWindow MsgWindow;


	// Use this for initialization
	void Update () {
		if(HasMessage == true)
        {
            CallMessage(Message);
        }
	}

    // Calls a message statement
    void CallMessage(string message)
    {
        MsgWindow.InputText(message);
    }
    //Adds an item

    //Triggers an event
}
