﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Landmarks : MonoBehaviour {
    //The exp rewarded per landmark
    public int AreaExp = 20;
    public int LandmarkExp = 50;
    public int SecretExp = 100;

    public bool IsArea = false;
    public bool IsLandmark = true;
    public bool IsSecretArea = false;
    public GameObject manager;
    public Text AreaText;

    public Animator anim;

    bool canTouch = true;
    void OnTriggerEnter2D(Collider2D col)
    {
        if (canTouch == true)
        {

            print("Touched by " + col.gameObject.name);
            List<GameObject> stats = GlobalScripts.GetChildren(manager);
            if (col.gameObject.name == "Player")
            {

                for (int i = 0; i < stats.Count; i++)
                {
                    //print(stats[i].name);
                    if (IsArea == true)
                    {
                        stats[i].GetComponent<PartyStats>().AwardExp(AreaExp);

                        
                        StartCoroutine(WaitForAnimation(anim));
                    }
                    else if (IsLandmark == true)
                    {
                        stats[i].GetComponent<PartyStats>().AwardExp(LandmarkExp);
                    }
                    else if (IsSecretArea == true)
                    {
                        stats[i].GetComponent<PartyStats>().AwardExp(SecretExp);
                    }
                    else
                    {
                        print("Not an awardable area.");
                    }
                }
                canTouch = false;
            }
        }
    }

    //Fade out the text

    private IEnumerator WaitForAnimation(Animator animation)
    {
        AnimatorClipInfo[] info = animation.GetCurrentAnimatorClipInfo(0);
        anim.SetBool("AreaEnter", true);
        yield return new WaitForSeconds(info[0].clip.length*2+0.2f);
        anim.SetBool("AreaEnter", false);
    }
}