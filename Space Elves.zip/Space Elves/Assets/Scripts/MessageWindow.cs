﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MessageWindow : MonoBehaviour {

    public Text MessageText;
    //The speed the text scrolls in frames.
    public int MessageSpeed = 120;
    public GameObject MessageBox;
    bool canPushKey = false;

    // Use this for initialization
    //void Start() {
    //    InputText("Hello World");
    //}

    void Update()
    {
        if (canPushKey == true)
        {
            if (Input.GetKey(KeyCode.X)||Input.GetKey(KeyCode.Return))
            {
                ResetBox();
            }
        }
    }

    public void InputText(string Message)
    {
        bool canPushKey = false;
        MessageBox.SetActive(true);
        StartCoroutine(WaitTime(MessageSpeed, Message));
        
    }

    IEnumerator WaitTime(int time, string Message)
    {
        char[] letters;
        MessageText.text = "";
        letters = Message.ToCharArray();
        print(letters.Length.ToString());
        for (int i = 0; i < letters.Length; i++)
        {
            MessageText.text = MessageText.text + letters[i];
            yield return time;
            if (i == letters.Length - 1)
            {
                canPushKey = true;
            }
        }
    }
    public void ResetBox()
    {
        MessageText.text = "";
        MessageBox.SetActive(false);
        canPushKey = false;
    }
}
