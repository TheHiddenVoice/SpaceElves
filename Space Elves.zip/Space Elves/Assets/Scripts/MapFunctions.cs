﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MapFunctions : MonoBehaviour {
    
    public int DiscoverHiddenArea(int exp)
    {
        return exp;
    }

    public int DiscoverLandmark(int exp)
    {
        return exp;
    }

    public int DiscoverArea(int exp)
    {
        return exp;
    }
}
